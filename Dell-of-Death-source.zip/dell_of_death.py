from __future__ import annotations

"""
Drivers of Death
Death's Head Software

A Windows driver scanning, identification, and installation tool.
Uses Windows Management Instrumentation (WMI) and Windows Update API
to detect missing/outdated drivers and install them.

Requirements:
    pip install PyQt6 cabarchive
    (wmi and pywin32 optional — falls back to PowerShell/WMIC if absent)
"""

import sys
import os
import time
import subprocess
import json
import re
import threading
import ctypes
import urllib.request
import urllib.error
import tempfile
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Optional

# --- Windows Taskbar Icon Fix & UAC Elevation ---

def _set_app_user_model_id():
    """Set AppUserModelID so Windows shows the correct taskbar icon."""
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "DeathsHeadSoftware.DellOfDeath.1.0"
        )
    except Exception:
        pass


def _require_admin():
    """
    If not running as administrator, re-launch with UAC elevation and exit.
    Driver installation requires admin rights on Windows.
    """
    try:
        is_admin = ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        is_admin = False

    if not is_admin:
        try:
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas",
                sys.executable,
                " ".join(f'"{a}"' for a in sys.argv),
                None, 1
            )
        except Exception:
            pass
        sys.exit(0)


_set_app_user_model_id()

# --- PyQt6 Imports ---
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QTimer, QSize, QSortFilterProxyModel,
    QAbstractTableModel, QModelIndex
)
from PyQt6.QtGui import (
    QColor, QFont, QPainter, QPixmap, QIcon, QBrush, QPalette,
    QFontMetrics, QAction
)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QSplashScreen,
    QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QTableView, QHeaderView, QProgressBar, QTextEdit, QSplitter,
    QFrame, QTabWidget, QComboBox, QCheckBox, QMessageBox,
    QFileDialog, QStatusBar, QMenuBar, QMenu, QToolBar,
    QAbstractItemView, QStyledItemDelegate, QStyleOptionViewItem,
    QSizePolicy, QScrollArea, QGroupBox, QLineEdit, QDialog,
    QDialogButtonBox
)

# --- Global Definitions ---
APP_NAME    = "Dell of Death"
APP_VERSION = "1.0.0"
ORG_NAME    = "Death's Head Software"

# --- Theme Colors ---
BG_DARK    = QColor(15, 15, 15)
BG_MID     = QColor(25, 25, 25)
BG_PANEL   = QColor(35, 35, 35)
BG_HOVER   = QColor(50, 50, 50)
ACCENT     = QColor(180, 0, 0)       # dark red
ACCENT_LT  = QColor(220, 30, 30)
TEXT_WHITE = QColor(240, 240, 240)
TEXT_GREY  = QColor(160, 160, 160)
TEXT_DIM   = QColor(100, 100, 100)
SUCCESS    = QColor(0, 180, 80)
WARNING    = QColor(220, 160, 0)
DANGER     = QColor(220, 40, 40)
INFO       = QColor(0, 140, 220)

# =============================================================================
# Driver Status Constants
# =============================================================================
STATUS_OK        = "OK"
STATUS_MISSING   = "Missing"
STATUS_OUTDATED  = "Outdated"
STATUS_ERROR     = "Error"
STATUS_UNKNOWN   = "Unknown"
STATUS_UPDATING  = "Updating..."
STATUS_UPDATED   = "Updated"

STATUS_COLORS = {
    STATUS_OK:       SUCCESS,
    STATUS_MISSING:  DANGER,
    STATUS_OUTDATED: WARNING,
    STATUS_ERROR:    DANGER,
    STATUS_UNKNOWN:  TEXT_DIM,
    STATUS_UPDATING: INFO,
    STATUS_UPDATED:  SUCCESS,
}

# =============================================================================
# WMI / Windows Driver Detection
# =============================================================================

def _run_powershell(cmd: str, timeout: int = 30) -> str:
    """Run a PowerShell command and return stdout."""
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-Command", cmd],
            capture_output=True, text=True, timeout=timeout,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        return result.stdout.strip()
    except Exception as e:
        return f"ERROR: {e}"


def _run_wmic(args: list[str]) -> str:
    """Run a WMIC command and return stdout."""
    try:
        result = subprocess.run(
            ["wmic"] + args,
            capture_output=True, text=True, timeout=30,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        return result.stdout.strip()
    except Exception as e:
        return f"ERROR: {e}"


def get_all_drivers() -> list[dict]:
    """
    Query Windows for all installed PnP drivers via PowerShell.
    Returns a list of driver dicts.
    """
    ps_cmd = r"""
    Get-PnpDevice | Select-Object -Property `
        FriendlyName, Class, InstanceId, Status, ConfigManagerErrorCode, Manufacturer, Present |
    ConvertTo-Json -Depth 2
    """
    raw = _run_powershell(ps_cmd, timeout=60)
    if raw.startswith("ERROR:") or not raw:
        return []
    try:
        data = json.loads(raw)
        if isinstance(data, dict):
            data = [data]
        return data or []
    except json.JSONDecodeError:
        return []


def get_driver_details(instance_id: str) -> dict:
    """
    Get full driver version details for a specific device.
    """
    safe_id = instance_id.replace("'", "''")
    ps_cmd = f"""
    Get-PnpDeviceProperty -InstanceId '{safe_id}' |
    Where-Object {{ $_.KeyName -in @(
        'DEVPKEY_Device_DriverVersion',
        'DEVPKEY_Device_DriverDate',
        'DEVPKEY_Device_DriverProvider',
        'DEVPKEY_Device_DriverDesc'
    )}} |
    Select-Object KeyName, Data |
    ConvertTo-Json -Depth 2
    """
    raw = _run_powershell(ps_cmd, timeout=20)
    result = {}
    if raw and not raw.startswith("ERROR:"):
        try:
            props = json.loads(raw)
            if isinstance(props, dict):
                props = [props]
            for p in props:
                key = p.get("KeyName", "")
                val = p.get("Data", "")
                if "DriverVersion" in key:
                    result["version"] = str(val)
                elif "DriverDate" in key:
                    result["date"] = str(val)
                elif "DriverProvider" in key:
                    result["provider"] = str(val)
                elif "DriverDesc" in key:
                    result["description"] = str(val)
        except Exception:
            pass
    return result


def get_problem_devices() -> list[str]:
    """Return InstanceIds of devices with errors (ConfigManagerErrorCode != 0)."""
    ps_cmd = r"""
    Get-PnpDevice | Where-Object { $_.Status -ne 'OK' } |
    Select-Object -ExpandProperty InstanceId
    """
    raw = _run_powershell(ps_cmd, timeout=30)
    if raw.startswith("ERROR:") or not raw:
        return []
    return [line.strip() for line in raw.splitlines() if line.strip()]


def update_driver_via_windows_update(instance_id: str) -> tuple[bool, str]:
    """
    Attempt to update a driver using Windows Update / PnP manager.
    Returns (success, message).
    """
    safe_id = instance_id.replace("'", "''")
    ps_cmd = f"Update-PnpDriver -InstanceId '{safe_id}' -Confirm:$false 2>&1"
    raw = _run_powershell(ps_cmd, timeout=120)
    if "ERROR:" in raw or "error" in raw.lower():
        return False, raw
    return True, raw or "Driver update attempted."


def scan_dxdiag() -> dict:
    """
    Run dxdiag and parse key system info for display.
    Returns dict with system/display/audio info.
    """
    info = {}
    try:
        tmp = Path(os.environ.get("TEMP", "C:/Temp")) / "dxdiag_dod.txt"
        subprocess.run(
            ["dxdiag", "/t", str(tmp)],
            timeout=30, creationflags=subprocess.CREATE_NO_WINDOW
        )
        deadline = time.time() + 25
        while not tmp.exists() and time.time() < deadline:
            time.sleep(0.5)
        if tmp.exists():
            text = tmp.read_text(errors="ignore")
            tmp.unlink(missing_ok=True)
            for line in text.splitlines():
                if ":" in line:
                    k, _, v = line.partition(":")
                    k = k.strip()
                    v = v.strip()
                    if k in ("OS", "Processor", "Memory", "DirectX Version",
                             "Card name", "Display Memory", "Driver Version",
                             "Driver Date/Size", "Sound Devices"):
                        info[k] = v
    except Exception as e:
        info["error"] = str(e)
    return info


# =============================================================================
# Driver Data Model
# =============================================================================

DRIVER_COLUMNS = ["Device Name", "Class", "Status", "Version", "Provider", "Driver Date"]

class DriverTableModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._data: list[dict] = []

    def rowCount(self, parent=QModelIndex()):
        return len(self._data)

    def columnCount(self, parent=QModelIndex()):
        return len(DRIVER_COLUMNS)

    def data(self, index: QModelIndex, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        row = self._data[index.row()]
        col = index.column()

        if role == Qt.ItemDataRole.DisplayRole:
            col_map = {
                0: row.get("name", ""),
                1: row.get("class", ""),
                2: row.get("status", STATUS_UNKNOWN),
                3: row.get("version", "—"),
                4: row.get("provider", "—"),
                5: row.get("date", "—"),
            }
            return col_map.get(col, "")

        if role == Qt.ItemDataRole.ForegroundRole:
            if col == 2:
                status = row.get("status", STATUS_UNKNOWN)
                color = STATUS_COLORS.get(status, TEXT_GREY)
                return QBrush(color)
            return QBrush(TEXT_WHITE)

        if role == Qt.ItemDataRole.BackgroundRole:
            return QBrush(BG_MID if index.row() % 2 == 0 else BG_PANEL)

        if role == Qt.ItemDataRole.UserRole:
            return row

        return None

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole:
            if orientation == Qt.Orientation.Horizontal:
                return DRIVER_COLUMNS[section]
        if role == Qt.ItemDataRole.ForegroundRole:
            return QBrush(TEXT_WHITE)
        if role == Qt.ItemDataRole.BackgroundRole:
            return QBrush(BG_DARK)
        return None

    def load_drivers(self, drivers: list[dict]):
        self.beginResetModel()
        self._data = drivers
        self.endResetModel()

    def update_driver_status(self, instance_id: str, status: str):
        for i, row in enumerate(self._data):
            if row.get("instance_id") == instance_id:
                self._data[i]["status"] = status
                idx_start = self.index(i, 2)
                idx_end = self.index(i, 2)
                self.dataChanged.emit(idx_start, idx_end)
                break

    def get_driver(self, row_index: int) -> Optional[dict]:
        if 0 <= row_index < len(self._data):
            return self._data[row_index]
        return None

    def get_all_drivers(self) -> list[dict]:
        return list(self._data)

    def get_problem_drivers(self) -> list[dict]:
        return [d for d in self._data
                if d.get("status") in (STATUS_MISSING, STATUS_ERROR, STATUS_OUTDATED)]


# =============================================================================
# Worker Threads
# =============================================================================

class ScanWorker(QThread):
    """Background thread: scan all installed drivers."""
    progress     = pyqtSignal(int, str)          # percent, message
    driver_found = pyqtSignal(dict)              # one driver at a time
    finished     = pyqtSignal(list)              # full list when done
    error        = pyqtSignal(str)

    def run(self):
        self.progress.emit(5, "Querying PnP devices...")
        raw_devices = get_all_drivers()

        if not raw_devices:
            self.error.emit("No devices returned. Ensure you are running on Windows.")
            return

        total = len(raw_devices)
        drivers = []

        for i, dev in enumerate(raw_devices):
            pct = 10 + int((i / total) * 80)
            name = dev.get("FriendlyName") or dev.get("InstanceId", "Unknown")
            self.progress.emit(pct, f"Scanning: {name[:60]}")

            instance_id = dev.get("InstanceId", "")
            status_raw  = dev.get("Status", "")
            err_code    = dev.get("ConfigManagerErrorCode", 0)

            # Determine status
            if status_raw == "OK" and (err_code == 0 or err_code is None):
                status = STATUS_OK
            elif status_raw in ("Error", "Degraded", "Unknown") or err_code not in (0, None, "0"):
                status = STATUS_ERROR
            elif not dev.get("Present", True):
                status = STATUS_MISSING
            else:
                status = STATUS_UNKNOWN

            # Get version details for non-OK devices or sample the OK ones
            details = {}
            if status != STATUS_OK or (i % 5 == 0):
                details = get_driver_details(instance_id)

            driver = {
                "name":        name or "Unknown Device",
                "class":       dev.get("Class", "—"),
                "instance_id": instance_id,
                "status":      status,
                "version":     details.get("version", "—"),
                "provider":    details.get("provider", dev.get("Manufacturer", "—")),
                "date":        details.get("date", "—"),
                "present":     dev.get("Present", True),
                "error_code":  err_code,
            }
            drivers.append(driver)
            self.driver_found.emit(driver)

        self.progress.emit(100, f"Scan complete. {total} devices found.")
        self.finished.emit(drivers)


class UpdateWorker(QThread):
    """Background thread: update a list of drivers."""
    progress  = pyqtSignal(int, str)
    log       = pyqtSignal(str)
    finished  = pyqtSignal(int, int)   # (success_count, fail_count)
    driver_updated = pyqtSignal(str, str)  # (instance_id, new_status)

    def __init__(self, drivers: list[dict], parent=None):
        super().__init__(parent)
        self._drivers = drivers

    def run(self):
        total = len(self._drivers)
        success = 0
        fail = 0

        for i, drv in enumerate(self._drivers):
            pct = int((i / total) * 100)
            name = drv.get("name", "Unknown")
            iid  = drv.get("instance_id", "")
            self.progress.emit(pct, f"Updating: {name[:60]}")
            self.log.emit(f"[{datetime.now().strftime('%H:%M:%S')}] Updating: {name}")
            self.driver_updated.emit(iid, STATUS_UPDATING)

            ok, msg = update_driver_via_windows_update(iid)
            if ok:
                success += 1
                self.driver_updated.emit(iid, STATUS_UPDATED)
                self.log.emit(f"  ✓ Success: {msg[:120]}")
            else:
                fail += 1
                self.driver_updated.emit(iid, STATUS_ERROR)
                self.log.emit(f"  ✗ Failed:  {msg[:120]}")

        self.progress.emit(100, f"Update complete. {success} succeeded, {fail} failed.")
        self.finished.emit(success, fail)


# =============================================================================
# Dell Support — Detection, Catalog, and Installation
# =============================================================================

DELL_CATALOG_URL = (
    "https://downloads.dell.com/catalog/CatalogPC.cab"
)
DELL_CATALOG_XML  = "CatalogPC.xml"
DELL_DOWNLOAD_BASE = "https://downloads.dell.com/"

# Category display names
DELL_CATEGORY_NAMES = {
    "BI": "BIOS",
    "FW": "Firmware",
    "DR": "Driver",
    "UT": "Utility / Application",
    "IN": "Install",
    "OS": "OS Recovery",
}


def detect_dell() -> dict:
    """
    Returns dict with keys: is_dell (bool), manufacturer, model, service_tag, system_id.
    system_id is the hex SKU number used in the Dell catalog XML (e.g. "07C4").
    """
    result = {"is_dell": False, "manufacturer": "", "model": "",
              "service_tag": "", "system_id": ""}
    try:
        mfr_raw   = _run_wmic(["computersystem", "get", "manufacturer", "/value"])
        model_raw = _run_wmic(["computersystem", "get", "model", "/value"])
        tag_raw   = _run_wmic(["bios", "get", "serialnumber", "/value"])
        sku_raw   = _run_wmic(["computersystem", "get", "systemskununber", "/value"])
        # systemskununber typo is intentional — wmic accepts prefix matches
        # fallback via PowerShell if blank
        for line in mfr_raw.splitlines():
            if line.lower().startswith("manufacturer="):
                result["manufacturer"] = line.split("=", 1)[1].strip()
        for line in model_raw.splitlines():
            if line.lower().startswith("model="):
                result["model"] = line.split("=", 1)[1].strip()
        for line in tag_raw.splitlines():
            if line.lower().startswith("serialnumber="):
                result["service_tag"] = line.split("=", 1)[1].strip()
        for line in sku_raw.splitlines():
            if "skun" in line.lower() and "=" in line:
                result["system_id"] = line.split("=", 1)[1].strip()

        # More reliable SKU via PowerShell
        if not result["system_id"]:
            ps = "(Get-WmiObject -Class Win32_ComputerSystem).SystemSKUNumber"
            sku = _run_powershell(ps, timeout=10).strip()
            if sku and sku not in ("", "None", "ERROR"):
                result["system_id"] = sku

        result["is_dell"] = "dell" in result["manufacturer"].lower()
    except Exception as e:
        result["error"] = str(e)
    return result


def _extract_cab(cab_path: str, dest_dir: str) -> tuple[bool, str]:
    """
    Extract a .cab file. Uses cabarchive (pure Python) as the primary method,
    falls back to Windows expand.exe if unavailable.
    Returns (success, error_message).
    """
    dest = Path(dest_dir)

    # --- Primary: pure-Python cabarchive (pip install cabarchive) ---
    try:
        import cabarchive
        cab = cabarchive.CabArchive(buf=Path(cab_path).read_bytes())
        for fname, cfile in cab.items():
            out = dest / fname
            out.write_bytes(cfile.buf)
        return True, ""
    except ImportError:
        pass  # not installed — fall through to expand.exe
    except Exception as e:
        return False, f"cabarchive error: {e}"

    # --- Fallback: Windows expand.exe ---
    strategies = [
        ["expand", cab_path, "-F:*", dest_dir],
        ["expand", "-F:*", cab_path, dest_dir],
    ]
    last_err = "cabarchive not installed and expand.exe unavailable."
    for cmd in strategies:
        try:
            r = subprocess.run(
                cmd, capture_output=True, text=True, timeout=120,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            if r.returncode == 0:
                return True, ""
            last_err = r.stderr or r.stdout or f"exit code {r.returncode}"
        except Exception as e:
            last_err = str(e)

    return False, last_err


# Known Dell brand name prefixes to strip when matching model numbers
_DELL_BRAND_PREFIXES = [
    "latitude", "inspiron", "optiplex", "precision", "xps", "vostro",
    "alienware", "g series", "poweredge", "venue", "chromebook",
]


def _dell_model_tokens(model: str) -> list[str]:
    """
    Extract meaningful tokens from a WMI model string for catalog matching.
    e.g. "Latitude E7270" -> ["latitude", "e7270", "e7270", "7270"]
    Returns multiple forms so we hit the catalog's short name format.
    """
    low = model.lower().strip()
    tokens = set(low.split())
    # Strip brand prefixes and keep the remainder as a token too
    stripped = low
    for prefix in _DELL_BRAND_PREFIXES:
        stripped = stripped.replace(prefix, "").strip()
    if stripped:
        tokens.add(stripped)
        # Also add numeric-only part (e.g. "7270" from "e7270")
        nums = re.sub(r"[^0-9]", "", stripped)
        if nums:
            tokens.add(nums)
    # Remove very short tokens that would cause false matches
    return [t for t in tokens if len(t) >= 3]


def _parse_dell_catalog(xml_path: str, model: str, system_id: str = "") -> list[dict]:
    """
    Parse CatalogPC.xml and return driver packages matching this system model.
    Uses ElementTree — no third-party XML library needed.
    """
    import xml.etree.ElementTree as ET

    packages = []
    diagnostics = []
    model_tokens  = _dell_model_tokens(model)
    system_id_up  = system_id.upper().strip()   # e.g. "07C4"

    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()

        # Strip XML namespace if present
        ns_match = re.match(r'\{[^}]+\}', root.tag)
        ns = ns_match.group(0) if ns_match else ""

        # Discover the actual component tag
        component_tag = None
        for candidate in ("SoftwareComponent", "softwareComponent",
                          "SoftwareBundle",   "softwareBundle"):
            if root.find(f"{ns}{candidate}") is not None:
                component_tag = f"{ns}{candidate}"
                break
        if component_tag is None:
            for child in root:
                for candidate in ("SoftwareComponent", "softwareComponent"):
                    if child.find(f"{ns}{candidate}") is not None:
                        component_tag = f"{ns}{candidate}"
                        root = child
                        break
                if component_tag:
                    break

        all_components = list(root.findall(component_tag or "NONE"))
        diagnostics.append(f"root tag: {root.tag}")
        diagnostics.append(f"namespace: '{ns}'")
        diagnostics.append(f"component tag: {component_tag}")
        diagnostics.append(f"system_id: '{system_id_up}'")
        diagnostics.append(f"model tokens: {model_tokens}")
        diagnostics.append(f"total components: {len(all_components)}")

        if not component_tag:
            child_tags = [c.tag for c in list(root)[:5]]
            diagnostics.append(f"root children: {child_tags}")
            packages.append({
                "name": "Catalog structure unrecognised — see description",
                "desc": " | ".join(diagnostics),
                "category": "Error", "version": "", "date": "",
                "path": "", "url": "", "size": "", "os_list": [], "status": "Error"
            })
            return packages

        matched_count = 0
        for pkg in all_components:
            supported = pkg.find(f"{ns}SupportedSystems")
            if supported is None:
                continue

            matched = False
            for brand in supported.findall(f"{ns}Brand"):
                for model_el in brand.findall(f"{ns}Model"):
                    # PRIMARY: match on systemID hex (most reliable)
                    pkg_sys_id = model_el.get("systemID", "").upper()
                    if system_id_up and pkg_sys_id == system_id_up:
                        matched = True
                        break
                    # FALLBACK: match on name tokens
                    short    = model_el.get("name", "").lower()
                    sys_name = f"{pkg_sys_id.lower()} {short}"
                    if any(tok in sys_name for tok in model_tokens):
                        matched = True
                        break
                if matched:
                    break

            if not matched:
                continue
            matched_count += 1

            # Extract package metadata
            name_el = pkg.find(f"{ns}Name")
            desc_el = pkg.find(f"{ns}Description")
            cat_el  = pkg.find(f"{ns}Category")
            size_el = pkg.find(f"{ns}Size")

            def _display(el):
                if el is None: return ""
                d = el.find(f"{ns}Display")
                return (d.text or "") if d is not None else (el.text or "")

            name     = _display(name_el)
            desc     = _display(desc_el)
            cat_val  = cat_el.get("value", "") if cat_el is not None else ""
            cat_disp = DELL_CATEGORY_NAMES.get(cat_val, cat_val or "Other")

            path    = pkg.get("path", "")
            version = pkg.get("dellVersion", pkg.get("vendorVersion", ""))
            date    = pkg.get("dateTime", "")[:10]
            size_b  = int(size_el.text) if (size_el is not None and
                                             size_el.text and
                                             size_el.text.isdigit()) else 0
            size_mb = f"{size_b / 1_048_576:.1f} MB" if size_b else "—"

            os_nodes = pkg.findall(f".//{ns}OperatingSystem")
            os_list  = list({o.get("osCode", "") for o in os_nodes if o.get("osCode")})

            packages.append({
                "name":     name or path.split("/")[-1],
                "desc":     desc,
                "category": cat_disp,
                "version":  version,
                "date":     date,
                "path":     path,
                "url":      DELL_DOWNLOAD_BASE + path,
                "size":     size_mb,
                "os_list":  os_list,
                "status":   "Available",
            })

        # If nothing matched, add a diagnostic entry so the user sees why
        if matched_count == 0:
            # Dump SupportedSystems from several components to find a Model tag
            import xml.etree.ElementTree as ET2
            sample_xml = ""
            for _pkg in root.findall(component_tag)[:50]:
                sup = _pkg.find(f"{ns}SupportedSystems")
                if sup is not None:
                    raw = ET2.tostring(sup, encoding="unicode")
                    if "<Model" in raw:
                        sample_xml = raw[:800]
                        break
            if not sample_xml:
                # Just dump the first one regardless
                first_pkg = next(iter(root.findall(component_tag)), None)
                if first_pkg is not None:
                    sup = first_pkg.find(f"{ns}SupportedSystems")
                    if sup is not None:
                        sample_xml = ET2.tostring(sup, encoding="unicode")[:800]
            diagnostics.append(f"sample XML: {sample_xml}")
            diag_str = " | ".join(diagnostics)
            packages.append({
                "name": f"No packages matched model '{model}' — see description",
                "desc": diag_str,
                "category": "Diagnostic", "version": "", "date": "",
                "path": "", "url": "", "size": "", "os_list": [], "status": "No Match"
            })

    except Exception as e:
        packages.append({"name": f"Parse error: {e}", "category": "Error",
                         "version": "", "date": "", "path": "", "url": "",
                         "size": "", "os_list": [], "status": "Error", "desc": ""})

    # Sort: BIOS first, then Firmware, then Drivers, then rest
    cat_order = {"BIOS": 0, "Firmware": 1, "Driver": 2}
    packages.sort(key=lambda p: (cat_order.get(p["category"], 9), p["name"]))
    return packages


class DellCatalogWorker(QThread):
    """Downloads and parses the Dell driver catalog for this system model."""
    progress  = pyqtSignal(int, str)
    finished  = pyqtSignal(list)     # list of driver package dicts
    error     = pyqtSignal(str)
    info      = pyqtSignal(dict)     # detected system info

    def __init__(self, model: str, system_id: str = "", parent=None):
        super().__init__(parent)
        self._model = model
        self._system_id = system_id.upper().strip()

    def run(self):
        # Ensure cabarchive is available — install silently if not
        try:
            import cabarchive  # noqa: F401
        except ImportError:
            self.progress.emit(2, "Installing cabarchive dependency...")
            try:
                subprocess.run(
                    [sys.executable, "-m", "pip", "install", "--quiet", "cabarchive"],
                    capture_output=True, timeout=60
                )
            except Exception as e:
                self.error.emit(
                    f"Could not install 'cabarchive' package automatically.\n\n"
                    f"Please run:  pip install cabarchive\n\nError: {e}"
                )
                return

        self.progress.emit(5, "Downloading Dell driver catalog...")
        tmp_dir = Path(tempfile.mkdtemp(prefix="dod_dell_"))
        cab_path = tmp_dir / "CatalogPC.cab"
        xml_path = tmp_dir / DELL_CATALOG_XML

        try:
            # Download catalog CAB (~15–30 MB)
            def _reporthook(count, block, total):
                if total > 0:
                    pct = min(60, int(count * block / total * 60))
                    self.progress.emit(pct, f"Downloading catalog... "
                                            f"{min(count*block, total)//1024//1024} MB "
                                            f"/ {total//1024//1024} MB")

            urllib.request.urlretrieve(DELL_CATALOG_URL, str(cab_path), _reporthook)
        except Exception as e:
            self.error.emit(f"Catalog download failed: {e}\n\n"
                            "Check your internet connection.")
            return

        self.progress.emit(65, "Extracting catalog...")
        ok, err = _extract_cab(str(cab_path), str(tmp_dir))
        if not ok:
            self.error.emit(
                f"Failed to extract catalog CAB.\n\n"
                f"Error: {err}\n\n"
                "Ensure you are running on Windows (expand.exe required)."
            )
            return

        # Log all files found for diagnostics
        found_files = list(tmp_dir.iterdir())
        self.progress.emit(70, f"Extracted {len(found_files)} file(s), locating catalog XML...")

        # The CAB may contain CatalogPC.xml directly, or a .gz/.cab wrapper
        # Search broadly for any XML file
        xml_path = None
        for candidate in ["CatalogPC.xml", "catalog.xml", "Catalog.xml"]:
            p = tmp_dir / candidate
            if p.exists():
                xml_path = p
                break
        if xml_path is None:
            xmls = list(tmp_dir.glob("*.xml"))
            if xmls:
                # Pick the largest one (most likely the full catalog)
                xml_path = max(xmls, key=lambda f: f.stat().st_size)

        # Handle gzipped XML (some Dell catalog versions ship as .xml.gz or .gz)
        if xml_path is None:
            gzs = list(tmp_dir.glob("*.gz"))
            if gzs:
                import gzip
                gz_path = gzs[0]
                xml_path = tmp_dir / gz_path.stem
                self.progress.emit(72, "Decompressing gzipped catalog...")
                try:
                    with gzip.open(str(gz_path), "rb") as gz_in:
                        xml_path.write_bytes(gz_in.read())
                except Exception as e:
                    self.error.emit(f"Failed to decompress catalog: {e}")
                    return

        if xml_path is None:
            file_list = ", ".join(f.name for f in found_files) or "(none)"
            self.error.emit(
                f"CatalogPC.xml not found after extraction.\n\n"
                f"Files found in archive: {file_list}\n\n"
                "The Dell catalog format may have changed. Please report this."
            )
            return

        self.progress.emit(75, f"Parsing catalog for model: {self._model} (SKU: {self._system_id})...")
        packages = _parse_dell_catalog(str(xml_path), self._model, self._system_id)

        # Cleanup
        try:
            import shutil
            shutil.rmtree(str(tmp_dir), ignore_errors=True)
        except Exception:
            pass

        self.progress.emit(100, f"Found {len(packages)} packages for this system.")
        self.finished.emit(packages)


class DellInstallWorker(QThread):
    """Downloads and silently installs one or more Dell driver packages."""
    progress       = pyqtSignal(int, str)
    log            = pyqtSignal(str)
    pkg_status     = pyqtSignal(str, str)   # (url, new_status)
    finished       = pyqtSignal(int, int)   # (success, fail)

    def __init__(self, packages: list[dict], parent=None):
        super().__init__(parent)
        self._packages = packages

    def run(self):
        tmp_dir = Path(tempfile.mkdtemp(prefix="dod_dell_inst_"))
        total   = len(self._packages)
        success = 0
        fail    = 0

        for i, pkg in enumerate(self._packages):
            pct  = int(i / total * 100)
            name = pkg.get("name", "Unknown")
            url  = pkg.get("url", "")
            self.progress.emit(pct, f"Downloading: {name[:60]}")
            self.log.emit(f"[{datetime.now().strftime('%H:%M:%S')}] Downloading: {name}")
            self.pkg_status.emit(url, "Downloading...")

            fname    = url.split("/")[-1]
            dl_path  = tmp_dir / fname

            try:
                urllib.request.urlretrieve(url, str(dl_path))
            except Exception as e:
                self.log.emit(f"  ✗ Download failed: {e}")
                self.pkg_status.emit(url, "Download Failed")
                fail += 1
                continue

            self.log.emit(f"  Installing: {fname}")
            self.pkg_status.emit(url, "Installing...")
            self.progress.emit(pct + int(1 / total * 50), f"Installing: {name[:60]}")

            try:
                ext = fname.lower().split(".")[-1]
                if ext == "exe":
                    # Dell EXEs accept /s for silent install
                    result = subprocess.run(
                        [str(dl_path), "/s"],
                        timeout=300, capture_output=True,
                        creationflags=subprocess.CREATE_NO_WINDOW
                    )
                    ok = result.returncode in (0, 2, 3010)  # 3010 = reboot required
                elif ext == "msi":
                    result = subprocess.run(
                        ["msiexec", "/i", str(dl_path), "/qn", "/norestart"],
                        timeout=300, capture_output=True,
                        creationflags=subprocess.CREATE_NO_WINDOW
                    )
                    ok = result.returncode in (0, 3010)
                else:
                    self.log.emit(f"  ✗ Unknown installer type: {ext}")
                    self.pkg_status.emit(url, "Skipped")
                    fail += 1
                    continue

                if ok:
                    success += 1
                    self.pkg_status.emit(url, "Installed ✓")
                    self.log.emit(f"  ✓ Installed (code {result.returncode})")
                else:
                    fail += 1
                    self.pkg_status.emit(url, "Install Failed")
                    self.log.emit(f"  ✗ Failed (code {result.returncode})")

            except subprocess.TimeoutExpired:
                fail += 1
                self.pkg_status.emit(url, "Timed Out")
                self.log.emit("  ✗ Timed out after 5 minutes")
            except Exception as e:
                fail += 1
                self.pkg_status.emit(url, "Error")
                self.log.emit(f"  ✗ Error: {e}")

        # Cleanup downloads
        try:
            import shutil
            shutil.rmtree(str(tmp_dir), ignore_errors=True)
        except Exception:
            pass

        self.progress.emit(100, f"Dell install complete. {success} succeeded, {fail} failed.")
        self.finished.emit(success, fail)


# =============================================================================
# Dell Tab Widget
# =============================================================================

DELL_PKG_COLUMNS = ["Package Name", "Category", "Version", "Date", "Size", "Status"]


class DellPackageModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._data: list[dict] = []

    def rowCount(self, parent=QModelIndex()):
        return len(self._data)

    def columnCount(self, parent=QModelIndex()):
        return len(DELL_PKG_COLUMNS)

    def data(self, index: QModelIndex, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        row = self._data[index.row()]
        col = index.column()

        if role == Qt.ItemDataRole.DisplayRole:
            return {
                0: row.get("name", ""),
                1: row.get("category", ""),
                2: row.get("version", ""),
                3: row.get("date", ""),
                4: row.get("size", ""),
                5: row.get("status", "Available"),
            }.get(col, "")

        if role == Qt.ItemDataRole.ForegroundRole:
            if col == 5:
                s = row.get("status", "")
                if "✓" in s or s == "Installed ✓":
                    return QBrush(SUCCESS)
                if "Failed" in s or "Error" in s or "Timed" in s:
                    return QBrush(DANGER)
                if s in ("Downloading...", "Installing..."):
                    return QBrush(INFO)
                return QBrush(TEXT_GREY)
            return QBrush(TEXT_WHITE)

        if role == Qt.ItemDataRole.BackgroundRole:
            return QBrush(BG_MID if index.row() % 2 == 0 else BG_PANEL)

        if role == Qt.ItemDataRole.UserRole:
            return row

        return None

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return DELL_PKG_COLUMNS[section]
        if role == Qt.ItemDataRole.ForegroundRole:
            return QBrush(TEXT_WHITE)
        if role == Qt.ItemDataRole.BackgroundRole:
            return QBrush(BG_DARK)
        return None

    def load(self, packages: list[dict]):
        self.beginResetModel()
        self._data = packages
        self.endResetModel()

    def update_status(self, url: str, status: str):
        for i, row in enumerate(self._data):
            if row.get("url") == url:
                self._data[i]["status"] = status
                idx = self.index(i, 5)
                self.dataChanged.emit(idx, idx)
                break

    def get_package(self, row: int) -> Optional[dict]:
        return self._data[row] if 0 <= row < len(self._data) else None

    def get_all(self) -> list[dict]:
        return list(self._data)

    def get_selected_urls(self, rows: list[int]) -> list[dict]:
        return [self._data[r] for r in rows if 0 <= r < len(self._data)]


class DellTab(QWidget):
    """Self-contained Dell driver update tab."""

    log_message = pyqtSignal(str, str)   # (msg, color_hex)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._dell_info: dict = {}
        self._catalog_worker:  Optional[DellCatalogWorker]  = None
        self._install_worker:  Optional[DellInstallWorker]  = None
        self._all_packages:    list[dict] = []
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 6)
        layout.setSpacing(8)

        # --- System info bar ---
        info_group = QGroupBox("System Detection")
        info_layout = QHBoxLayout(info_group)
        info_layout.setSpacing(20)

        self._lbl_manufacturer = self._info_field("Manufacturer", "—")
        self._lbl_model        = self._info_field("Model", "—")
        self._lbl_tag          = self._info_field("Service Tag", "—")
        self._lbl_sku          = self._info_field("System ID (SKU)", "—")
        self._lbl_pkg_count    = self._info_field("Packages Found", "—")

        for w in (self._lbl_manufacturer, self._lbl_model,
                  self._lbl_tag, self._lbl_sku, self._lbl_pkg_count):
            info_layout.addWidget(w)
        info_layout.addStretch()

        layout.addWidget(info_group)

        # --- Toolbar ---
        tool_row = QHBoxLayout()
        self._fetch_btn       = make_button("⟳  Fetch Dell Catalog", accent=True)
        self._install_sel_btn = make_button("↓  Install Selected")
        self._install_all_btn = make_button("↓  Install All", danger=True)
        self._cat_filter      = QComboBox()
        self._cat_filter.addItem("All Categories")
        self._cat_filter.setFixedWidth(200)
        self._search_dell     = QLineEdit()
        self._search_dell.setPlaceholderText("Filter by name...")
        self._search_dell.setFixedWidth(200)

        self._fetch_btn.clicked.connect(self._fetch_catalog)
        self._install_sel_btn.clicked.connect(self._install_selected)
        self._install_all_btn.clicked.connect(self._install_all)
        self._cat_filter.currentTextChanged.connect(self._apply_filter)
        self._search_dell.textChanged.connect(self._apply_filter)

        for w in (self._fetch_btn, self._install_sel_btn, self._install_all_btn):
            tool_row.addWidget(w)
        tool_row.addStretch()
        tool_row.addWidget(QLabel("Category:"))
        tool_row.addWidget(self._cat_filter)
        tool_row.addWidget(self._search_dell)
        layout.addLayout(tool_row)

        # --- Progress ---
        self._progress = QProgressBar()
        self._progress.setFixedHeight(16)
        self._progress.setVisible(False)
        layout.addWidget(self._progress)

        # --- Package table ---
        self._model = DellPackageModel()
        self._proxy = QSortFilterProxyModel()
        self._proxy.setSourceModel(self._model)
        self._proxy.setFilterCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)

        self._table = QTableView()
        self._table.setModel(self._proxy)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self._table.setSortingEnabled(True)
        self._table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for col, w in enumerate([0, 150, 120, 100, 80, 120], 0):
            if col > 0:
                self._table.setColumnWidth(col, w)
        self._table.verticalHeader().setVisible(False)
        self._table.setAlternatingRowColors(False)
        self._table.selectionModel().selectionChanged.connect(self._on_selection)
        layout.addWidget(self._table, 1)

        # --- Description box ---
        self._desc_lbl = QLabel("Select a package to see its description.")
        self._desc_lbl.setFont(QFont("Courier", 9))
        self._desc_lbl.setStyleSheet(f"""
            color: {TEXT_GREY.name()};
            background: {BG_PANEL.name()};
            border: 1px solid #2a0000;
            border-radius: 3px;
            padding: 6px;
        """)
        self._desc_lbl.setWordWrap(True)
        self._desc_lbl.setFixedHeight(54)
        layout.addWidget(self._desc_lbl)

        # Initial state
        self._set_buttons_enabled(False)
        self._detect_system()

    def _info_field(self, label: str, value: str) -> QFrame:
        """Compact label+value display widget."""
        frame = QFrame()
        frame.setStyleSheet("QFrame { border: none; }")
        vl = QVBoxLayout(frame)
        vl.setContentsMargins(0, 0, 0, 0)
        vl.setSpacing(2)
        lbl = QLabel(label)
        lbl.setFont(QFont("Courier", 8))
        lbl.setStyleSheet(f"color: {TEXT_DIM.name()}; border: none;")
        val = QLabel(value)
        val.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        val.setStyleSheet(f"color: {TEXT_WHITE.name()}; border: none;")
        vl.addWidget(lbl)
        vl.addWidget(val)
        frame._val_lbl = val
        return frame

    def _set_field(self, frame: QFrame, text: str, color: QColor = None):
        frame._val_lbl.setText(text)
        if color:
            frame._val_lbl.setStyleSheet(f"color: {color.name()}; border: none;")

    def _detect_system(self):
        """Run detection immediately on tab load — it's fast (WMI)."""
        info = detect_dell()
        self._dell_info = info
        self._set_field(self._lbl_manufacturer, info.get("manufacturer", "—"))
        self._set_field(self._lbl_model,        info.get("model", "—"))
        self._set_field(self._lbl_tag,          info.get("service_tag", "—"))
        self._set_field(self._lbl_sku,          info.get("system_id", "—") or "—")

        if info.get("is_dell"):
            self._set_field(self._lbl_manufacturer, info["manufacturer"], SUCCESS)
            self.log_message.emit(
                f"Dell system detected: {info['model']} (Tag: {info['service_tag']})",
                SUCCESS.name()
            )
        else:
            mfr = info.get("manufacturer", "Unknown")
            self._fetch_btn.setEnabled(False)
            self._fetch_btn.setText(f"Not a Dell system ({mfr})")
            self.log_message.emit(
                f"System manufacturer is '{mfr}' — Dell catalog not available.",
                WARNING.name()
            )

    def _set_buttons_enabled(self, enabled: bool):
        self._install_sel_btn.setEnabled(enabled)
        self._install_all_btn.setEnabled(enabled)

    # ------------------------------------------------------------------
    # Catalog fetch
    # ------------------------------------------------------------------

    def _fetch_catalog(self):
        if self._catalog_worker and self._catalog_worker.isRunning():
            return
        if not self._dell_info.get("is_dell"):
            return

        model = self._dell_info.get("model", "")
        self._progress.setValue(0)
        self._progress.setVisible(True)
        self._fetch_btn.setEnabled(False)
        self._set_buttons_enabled(False)
        self._model.load([])
        self._cat_filter.clear()
        self._cat_filter.addItem("All Categories")
        self.log_message.emit("Fetching Dell driver catalog (this may take a moment)...",
                              INFO.name())

        self._catalog_worker = DellCatalogWorker(model, self._dell_info.get("system_id", ""), self)
        self._catalog_worker.progress.connect(self._on_catalog_progress)
        self._catalog_worker.finished.connect(self._on_catalog_finished)
        self._catalog_worker.error.connect(self._on_catalog_error)
        self._catalog_worker.start()

    def _on_catalog_progress(self, pct: int, msg: str):
        self._progress.setValue(pct)
        self.log_message.emit(msg, TEXT_GREY.name())

    def _on_catalog_finished(self, packages: list[dict]):
        self._all_packages = packages
        self._model.load(packages)
        self._progress.setVisible(False)
        self._fetch_btn.setEnabled(True)
        self._set_buttons_enabled(bool(packages))
        self._set_field(self._lbl_pkg_count, str(len(packages)),
                        SUCCESS if packages else WARNING)

        # Populate category filter
        cats = sorted({p["category"] for p in packages if p.get("category")})
        for c in cats:
            self._cat_filter.addItem(c)

        self.log_message.emit(
            f"Dell catalog loaded: {len(packages)} packages for {self._dell_info.get('model', 'this system')}.",
            SUCCESS.name()
        )

    def _on_catalog_error(self, msg: str):
        self._progress.setVisible(False)
        self._fetch_btn.setEnabled(True)
        self.log_message.emit(f"Dell catalog error: {msg}", DANGER.name())
        QMessageBox.critical(self.window(), "Dell Catalog Error", msg)

    # ------------------------------------------------------------------
    # Install
    # ------------------------------------------------------------------

    def _install_selected(self):
        idxs = self._table.selectionModel().selectedRows()
        if not idxs:
            return
        pkgs = []
        for idx in idxs:
            src = self._proxy.mapToSource(idx)
            p   = self._model.get_package(src.row())
            if p:
                pkgs.append(p)
        self._run_install(pkgs)

    def _install_all(self):
        if not self._all_packages:
            return
        self._run_install(self._all_packages)

    def _run_install(self, packages: list[dict]):
        if self._install_worker and self._install_worker.isRunning():
            self.log_message.emit("Install already in progress.", WARNING.name())
            return

        names = "\n".join(f"  • {p['name']}" for p in packages[:8])
        if len(packages) > 8:
            names += f"\n  … and {len(packages) - 8} more"

        resp = QMessageBox.question(
            self.window(), "Confirm Dell Install",
            f"Install {len(packages)} package(s) from Dell?\n\n{names}\n\n"
            "Packages will be downloaded and installed silently.\n"
            "A restart may be required afterwards.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if resp != QMessageBox.StandardButton.Yes:
            return

        self._progress.setValue(0)
        self._progress.setVisible(True)
        self._fetch_btn.setEnabled(False)
        self._set_buttons_enabled(False)
        self.log_message.emit(f"Starting Dell install: {len(packages)} package(s)...",
                              ACCENT_LT.name())

        self._install_worker = DellInstallWorker(packages, self)
        self._install_worker.progress.connect(self._on_install_progress)
        self._install_worker.log.connect(lambda m: self.log_message.emit(m, TEXT_GREY.name()))
        self._install_worker.pkg_status.connect(self._model.update_status)
        self._install_worker.finished.connect(self._on_install_finished)
        self._install_worker.start()

    def _on_install_progress(self, pct: int, msg: str):
        self._progress.setValue(pct)

    def _on_install_finished(self, success: int, fail: int):
        self._progress.setVisible(False)
        self._fetch_btn.setEnabled(True)
        self._set_buttons_enabled(True)
        color = SUCCESS.name() if fail == 0 else WARNING.name()
        self.log_message.emit(
            f"Dell install complete: {success} succeeded, {fail} failed.", color
        )
        if success > 0:
            QMessageBox.information(
                self.window(), "Dell Install Complete",
                f"{success} package(s) installed successfully, {fail} failed.\n\n"
                "A system restart may be required."
            )

    # ------------------------------------------------------------------
    # Filter
    # ------------------------------------------------------------------

    def _apply_filter(self):
        cat    = self._cat_filter.currentText()
        search = self._search_dell.text().strip().lower()
        visible = []
        for p in self._all_packages:
            if cat != "All Categories" and p.get("category") != cat:
                continue
            if search and search not in p.get("name", "").lower():
                continue
            visible.append(p)
        self._model.load(visible)

    def _on_selection(self):
        idxs = self._table.selectionModel().selectedRows()
        if len(idxs) == 1:
            src = self._proxy.mapToSource(idxs[0])
            p   = self._model.get_package(src.row())
            if p:
                self._desc_lbl.setText(p.get("desc") or "No description available.")
                return
        self._desc_lbl.setText("Select a package to see its description.")




def create_splash() -> Optional[QSplashScreen]:
    try:
        splash_path = Path(__file__).parent / "splash.png"
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(BG_DARK)
            pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.IgnoreAspectRatio,
                                   Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(pixmap)
            painter.setPen(TEXT_WHITE)
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            r = pixmap.rect(); r.setTop(40); r.setBottom(110)
            painter.drawText(r, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            fr = pixmap.rect(); fr.setTop(pixmap.height() - 60); fr.setBottom(pixmap.height() - 20)
            painter.drawText(fr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            # Fallback ASCII skull splash
            pixmap = QPixmap(800, 600)
            pixmap.fill(BG_DARK)
            painter = QPainter(pixmap)
            painter.setPen(TEXT_WHITE)
            # Title
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            r = pixmap.rect(); r.setTop(30); r.setBottom(100)
            painter.drawText(r, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            # Skull ASCII
            painter.setFont(QFont("Courier", 13))
            skull = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y = 220
            for line in skull:
                painter.drawText(230, y, line)
                y += 26
            # Footer
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            fr = pixmap.rect(); fr.setTop(pixmap.height() - 60); fr.setBottom(pixmap.height() - 20)
            painter.drawText(fr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None


# =============================================================================
# Summary Card Widget
# =============================================================================

class SummaryCard(QFrame):
    """A stat card widget for the dashboard row."""
    def __init__(self, label: str, value: str = "—", color: QColor = TEXT_WHITE, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.Shape.Box)
        self.setStyleSheet(f"""
            QFrame {{
                background: {BG_PANEL.name()};
                border: 1px solid {ACCENT.name()};
                border-radius: 4px;
            }}
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(4)

        self._value_lbl = QLabel(value)
        self._value_lbl.setFont(QFont("Courier", 26, QFont.Weight.Bold))
        self._value_lbl.setStyleSheet(f"color: {color.name()}; border: none;")
        self._value_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self._label_lbl = QLabel(label)
        self._label_lbl.setFont(QFont("Courier", 10))
        self._label_lbl.setStyleSheet(f"color: {TEXT_GREY.name()}; border: none;")
        self._label_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        layout.addWidget(self._value_lbl)
        layout.addWidget(self._label_lbl)

    def set_value(self, value: str, color: QColor = None):
        self._value_lbl.setText(value)
        if color:
            self._value_lbl.setStyleSheet(f"color: {color.name()}; border: none;")


# =============================================================================
# Log Panel
# =============================================================================

class LogPanel(QTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setFont(QFont("Courier", 9))
        self.setStyleSheet(f"""
            QTextEdit {{
                background: {BG_DARK.name()};
                color: {TEXT_GREY.name()};
                border: 1px solid #2a0000;
                border-radius: 2px;
            }}
        """)

    def append_log(self, msg: str, color: str = None):
        color = color or TEXT_GREY.name()
        ts = datetime.now().strftime("%H:%M:%S")
        self.append(f'<span style="color:{TEXT_DIM.name()}">[{ts}]</span> '
                    f'<span style="color:{color}">{msg}</span>')
        self.verticalScrollBar().setValue(self.verticalScrollBar().maximum())


# =============================================================================
# Detail Panel
# =============================================================================

class DriverDetailPanel(QFrame):
    """Shows details for the currently selected driver."""

    update_requested = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumWidth(260)
        self.setStyleSheet(f"""
            QFrame {{
                background: {BG_PANEL.name()};
                border: 1px solid #2a0000;
                border-radius: 4px;
            }}
            QLabel {{ border: none; }}
        """)
        self._current_driver = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        title = QLabel("Driver Details")
        title.setFont(QFont("Courier", 13, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {ACCENT_LT.name()};")
        layout.addWidget(title)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color: {ACCENT.name()};")
        layout.addWidget(sep)

        self._fields: dict[str, QLabel] = {}
        for field in ("Name", "Class", "Status", "Version", "Provider", "Date", "Instance ID"):
            row = QHBoxLayout()
            lbl = QLabel(f"{field}:")
            lbl.setFont(QFont("Courier", 9, QFont.Weight.Bold))
            lbl.setStyleSheet(f"color: {TEXT_GREY.name()};")
            lbl.setFixedWidth(90)
            val = QLabel("—")
            val.setFont(QFont("Courier", 9))
            val.setStyleSheet(f"color: {TEXT_WHITE.name()};")
            val.setWordWrap(True)
            row.addWidget(lbl)
            row.addWidget(val)
            layout.addLayout(row)
            self._fields[field] = val

        layout.addStretch()

        self._update_btn = QPushButton("Update This Driver")
        self._update_btn.setEnabled(False)
        self._update_btn.setFont(QFont("Courier", 10, QFont.Weight.Bold))
        self._update_btn.setStyleSheet(f"""
            QPushButton {{
                background: {ACCENT.name()};
                color: white;
                border: none;
                padding: 8px;
                border-radius: 3px;
            }}
            QPushButton:hover {{ background: {ACCENT_LT.name()}; }}
            QPushButton:disabled {{
                background: {BG_HOVER.name()};
                color: {TEXT_DIM.name()};
            }}
        """)
        self._update_btn.clicked.connect(self._on_update)
        layout.addWidget(self._update_btn)

    def load_driver(self, driver: dict):
        self._current_driver = driver
        status = driver.get("status", STATUS_UNKNOWN)
        color  = STATUS_COLORS.get(status, TEXT_GREY)

        self._fields["Name"].setText(driver.get("name", "—"))
        self._fields["Class"].setText(driver.get("class", "—"))
        self._fields["Status"].setText(status)
        self._fields["Status"].setStyleSheet(f"color: {color.name()};")
        self._fields["Version"].setText(driver.get("version", "—"))
        self._fields["Provider"].setText(driver.get("provider", "—"))
        self._fields["Date"].setText(driver.get("date", "—"))
        iid = driver.get("instance_id", "—")
        self._fields["Instance ID"].setText(iid[:48] + "…" if len(iid) > 48 else iid)

        self._update_btn.setEnabled(status in (STATUS_ERROR, STATUS_MISSING, STATUS_OUTDATED))

    def clear(self):
        self._current_driver = None
        for v in self._fields.values():
            v.setText("—")
            v.setStyleSheet(f"color: {TEXT_WHITE.name()};")
        self._update_btn.setEnabled(False)

    def _on_update(self):
        if self._current_driver:
            self.update_requested.emit(self._current_driver)


# =============================================================================
# Main Window
# =============================================================================

GLOBAL_STYLESHEET = f"""
QMainWindow, QWidget {{
    background: {BG_DARK.name()};
    color: {TEXT_WHITE.name()};
    font-family: 'Courier New', Courier, monospace;
}}
QMenuBar {{
    background: {BG_DARK.name()};
    color: {TEXT_WHITE.name()};
    border-bottom: 1px solid {ACCENT.name()};
}}
QMenuBar::item:selected {{
    background: {ACCENT.name()};
}}
QMenu {{
    background: {BG_MID.name()};
    color: {TEXT_WHITE.name()};
    border: 1px solid {ACCENT.name()};
}}
QMenu::item:selected {{
    background: {ACCENT.name()};
}}
QToolBar {{
    background: {BG_MID.name()};
    border-bottom: 1px solid {ACCENT.name()};
    spacing: 4px;
    padding: 3px;
}}
QStatusBar {{
    background: {BG_MID.name()};
    color: {TEXT_GREY.name()};
    border-top: 1px solid {ACCENT.name()};
    font-size: 10px;
}}
QTabWidget::pane {{
    border: 1px solid {ACCENT.name()};
    background: {BG_DARK.name()};
}}
QTabBar::tab {{
    background: {BG_MID.name()};
    color: {TEXT_GREY.name()};
    border: 1px solid #3a0000;
    padding: 6px 18px;
    font-size: 11px;
    font-family: 'Courier New', Courier, monospace;
}}
QTabBar::tab:selected {{
    background: {BG_DARK.name()};
    color: {TEXT_WHITE.name()};
    border-bottom: 2px solid {ACCENT_LT.name()};
}}
QTableView {{
    background: {BG_MID.name()};
    color: {TEXT_WHITE.name()};
    gridline-color: #1e1e1e;
    selection-background-color: {ACCENT.name()};
    selection-color: white;
    border: none;
    font-family: 'Courier New', Courier, monospace;
    font-size: 11px;
}}
QHeaderView::section {{
    background: {BG_DARK.name()};
    color: {ACCENT_LT.name()};
    border: none;
    border-right: 1px solid #2a0000;
    border-bottom: 1px solid {ACCENT.name()};
    padding: 5px 8px;
    font-weight: bold;
    font-family: 'Courier New', Courier, monospace;
    font-size: 11px;
}}
QScrollBar:vertical {{
    background: {BG_DARK.name()};
    width: 10px;
}}
QScrollBar::handle:vertical {{
    background: {ACCENT.name()};
    min-height: 20px;
    border-radius: 3px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
QProgressBar {{
    background: {BG_MID.name()};
    border: 1px solid {ACCENT.name()};
    border-radius: 3px;
    text-align: center;
    color: white;
    font-size: 10px;
    font-family: 'Courier New';
}}
QProgressBar::chunk {{
    background: {ACCENT.name()};
    border-radius: 2px;
}}
QPushButton {{
    background: {BG_PANEL.name()};
    color: {TEXT_WHITE.name()};
    border: 1px solid {ACCENT.name()};
    padding: 6px 14px;
    border-radius: 3px;
    font-family: 'Courier New', Courier, monospace;
    font-size: 11px;
}}
QPushButton:hover {{ background: {BG_HOVER.name()}; border-color: {ACCENT_LT.name()}; }}
QPushButton:pressed {{ background: {ACCENT.name()}; }}
QPushButton:disabled {{ color: {TEXT_DIM.name()}; border-color: #2a2a2a; }}
QLineEdit, QComboBox {{
    background: {BG_PANEL.name()};
    color: {TEXT_WHITE.name()};
    border: 1px solid #3a0000;
    border-radius: 3px;
    padding: 4px 8px;
    font-family: 'Courier New';
    font-size: 11px;
}}
QComboBox::drop-down {{ border: none; }}
QComboBox QAbstractItemView {{
    background: {BG_PANEL.name()};
    color: {TEXT_WHITE.name()};
    selection-background-color: {ACCENT.name()};
}}
QGroupBox {{
    border: 1px solid {ACCENT.name()};
    border-radius: 4px;
    margin-top: 8px;
    padding-top: 6px;
    color: {ACCENT_LT.name()};
    font-family: 'Courier New';
    font-weight: bold;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 6px;
}}
QCheckBox {{
    color: {TEXT_WHITE.name()};
    font-family: 'Courier New';
    font-size: 11px;
    spacing: 6px;
}}
QCheckBox::indicator {{
    width: 14px; height: 14px;
    background: {BG_PANEL.name()};
    border: 1px solid {ACCENT.name()};
    border-radius: 2px;
}}
QCheckBox::indicator:checked {{
    background: {ACCENT.name()};
}}
QSplitter::handle {{
    background: {ACCENT.name()};
    width: 2px;
    height: 2px;
}}
"""


def make_button(text: str, accent: bool = False, danger: bool = False) -> QPushButton:
    btn = QPushButton(text)
    btn.setFont(QFont("Courier", 10, QFont.Weight.Bold))
    if accent:
        btn.setStyleSheet(f"""
            QPushButton {{
                background: {ACCENT.name()};
                color: white;
                border: none;
                padding: 7px 18px;
                border-radius: 3px;
            }}
            QPushButton:hover {{ background: {ACCENT_LT.name()}; }}
            QPushButton:disabled {{ background: {BG_HOVER.name()}; color: {TEXT_DIM.name()}; }}
        """)
    elif danger:
        btn.setStyleSheet(f"""
            QPushButton {{
                background: #550000;
                color: {TEXT_WHITE.name()};
                border: 1px solid {DANGER.name()};
                padding: 7px 18px;
                border-radius: 3px;
            }}
            QPushButton:hover {{ background: {DANGER.name()}; }}
        """)
    return btn


class DriversOfDeath(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME}  |  {ORG_NAME}")
        self.resize(1200, 780)
        self.setMinimumSize(900, 600)

        # Window icon — reuse the app-level icon which already has all sizes baked in
        self.setWindowIcon(QApplication.instance().windowIcon())

        self._all_drivers:   list[dict] = []
        self._scan_worker:   Optional[ScanWorker]   = None
        self._update_worker: Optional[UpdateWorker] = None

        self._setup_ui()
        self._setup_menu()
        self.setStyleSheet(GLOBAL_STYLESHEET)

        self._log("Drivers of Death initialized. Click 'Scan System' to begin.")

    # ---------------------------------------------------------------
    # UI Setup
    # ---------------------------------------------------------------

    def _setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(10, 8, 10, 6)
        root.setSpacing(8)

        # --- Header bar ---
        header = QHBoxLayout()
        title_lbl = QLabel(APP_NAME)
        title_lbl.setFont(QFont("Courier", 20, QFont.Weight.Bold))
        title_lbl.setStyleSheet(f"color: {ACCENT_LT.name()};")
        org_lbl = QLabel(ORG_NAME)
        org_lbl.setFont(QFont("Courier", 10))
        org_lbl.setStyleSheet(f"color: {TEXT_DIM.name()};")
        org_lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        header.addWidget(title_lbl)
        header.addStretch()
        header.addWidget(org_lbl)
        root.addLayout(header)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color: {ACCENT.name()};")
        root.addWidget(sep)

        # --- Summary cards ---
        self._card_total    = SummaryCard("Total Devices",  "—", TEXT_WHITE)
        self._card_ok       = SummaryCard("OK",             "—", SUCCESS)
        self._card_problems = SummaryCard("Problems",       "—", DANGER)
        self._card_unknown  = SummaryCard("Unknown",        "—", TEXT_DIM)

        cards_row = QHBoxLayout()
        cards_row.setSpacing(8)
        for card in (self._card_total, self._card_ok, self._card_problems, self._card_unknown):
            cards_row.addWidget(card)
        root.addLayout(cards_row)

        # --- Toolbar row ---
        tool_row = QHBoxLayout()
        tool_row.setSpacing(6)

        self._scan_btn   = make_button("⟳  Scan System", accent=True)
        self._update_all_btn = make_button("↑  Update All Problems", danger=True)
        self._update_sel_btn = make_button("↑  Update Selected")
        self._export_btn     = make_button("⎙  Export Report")
        self._filter_combo   = QComboBox()
        self._filter_combo.addItems([
            "All Devices", "Problems Only", "OK Only", "Unknown Only",
            "Hardware Only (no VM/3rd-party)"
        ])
        self._filter_combo.setFixedWidth(170)
        self._search_box     = QLineEdit()
        self._search_box.setPlaceholderText("Filter by name...")
        self._search_box.setFixedWidth(200)

        self._scan_btn.clicked.connect(self._start_scan)
        self._update_all_btn.clicked.connect(self._update_all_problems)
        self._update_sel_btn.clicked.connect(self._update_selected)
        self._export_btn.clicked.connect(self._export_report)
        self._filter_combo.currentIndexChanged.connect(self._apply_filter)
        self._search_box.textChanged.connect(self._apply_filter)

        for w in (self._scan_btn, self._update_all_btn, self._update_sel_btn,
                  self._export_btn):
            tool_row.addWidget(w)
        tool_row.addStretch()
        tool_row.addWidget(QLabel("Filter:"))
        tool_row.addWidget(self._filter_combo)
        tool_row.addWidget(self._search_box)
        root.addLayout(tool_row)

        # --- Progress bar ---
        self._progress = QProgressBar()
        self._progress.setFixedHeight(16)
        self._progress.setValue(0)
        self._progress.setVisible(False)
        root.addWidget(self._progress)

        # --- Main splitter: table | detail ---
        main_splitter = QSplitter(Qt.Orientation.Horizontal)
        main_splitter.setHandleWidth(3)

        # Left: tab widget with driver table + log
        left_tabs = QTabWidget()

        # Driver table tab
        table_widget = QWidget()
        table_layout = QVBoxLayout(table_widget)
        table_layout.setContentsMargins(0, 4, 0, 0)
        table_layout.setSpacing(0)

        self._model  = DriverTableModel()
        self._proxy  = QSortFilterProxyModel()
        self._proxy.setSourceModel(self._model)
        self._proxy.setFilterCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)

        self._table = QTableView()
        self._table.setModel(self._proxy)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self._table.setSortingEnabled(True)
        self._table.horizontalHeader().setStretchLastSection(False)
        self._table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for col, w in enumerate([0, 110, 90, 120, 130, 110], 0):
            if col > 0:
                self._table.setColumnWidth(col, w)
        self._table.verticalHeader().setVisible(False)
        self._table.setAlternatingRowColors(False)
        self._table.selectionModel().selectionChanged.connect(self._on_selection_changed)

        table_layout.addWidget(self._table)
        left_tabs.addTab(table_widget, "Driver List")

        # Log tab
        self._log_panel = LogPanel()
        left_tabs.addTab(self._log_panel, "Operation Log")

        # Dell tab
        self._dell_tab = DellTab()
        self._dell_tab.log_message.connect(self._log)
        left_tabs.addTab(self._dell_tab, "Dell Updates")

        main_splitter.addWidget(left_tabs)

        # Right: detail panel
        self._detail_panel = DriverDetailPanel()
        self._detail_panel.update_requested.connect(self._update_single)
        main_splitter.addWidget(self._detail_panel)

        main_splitter.setSizes([860, 280])
        root.addWidget(main_splitter, 1)

        # --- Status bar ---
        self._status_bar = QStatusBar()
        self.setStatusBar(self._status_bar)
        self._status_lbl = QLabel("Ready.")
        self._status_bar.addWidget(self._status_lbl)
        self._version_lbl = QLabel(f"v{APP_VERSION}")
        self._status_bar.addPermanentWidget(self._version_lbl)

    def _setup_menu(self):
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("File")
        act_scan   = QAction("Scan System", self); act_scan.setShortcut("F5")
        act_export = QAction("Export Report...", self)
        act_quit   = QAction("Exit", self); act_quit.setShortcut("Ctrl+Q")
        act_scan.triggered.connect(self._start_scan)
        act_export.triggered.connect(self._export_report)
        act_quit.triggered.connect(self.close)
        file_menu.addActions([act_scan, act_export])
        file_menu.addSeparator()
        file_menu.addAction(act_quit)

        # Drivers menu
        drv_menu = menubar.addMenu("Drivers")
        act_upd_all = QAction("Update All Problems", self)
        act_upd_sel = QAction("Update Selected", self)
        act_upd_all.triggered.connect(self._update_all_problems)
        act_upd_sel.triggered.connect(self._update_selected)
        drv_menu.addActions([act_upd_all, act_upd_sel])

        # Help menu
        help_menu = menubar.addMenu("Help")
        act_about = QAction("About", self)
        act_about.triggered.connect(self._show_about)
        help_menu.addAction(act_about)

    # ---------------------------------------------------------------
    # Scan Logic
    # ---------------------------------------------------------------

    def _start_scan(self):
        if self._scan_worker and self._scan_worker.isRunning():
            return
        if self._update_worker and self._update_worker.isRunning():
            self._log("Cannot scan while an update is in progress.", WARNING.name())
            return

        self._all_drivers = []
        self._model.load_drivers([])
        self._detail_panel.clear()
        self._update_cards([], [], [], [])
        self._progress.setValue(0)
        self._progress.setVisible(True)
        self._scan_btn.setEnabled(False)
        self._update_all_btn.setEnabled(False)
        self._log("Starting system scan...", INFO.name())

        self._scan_worker = ScanWorker(self)
        self._scan_worker.progress.connect(self._on_scan_progress)
        self._scan_worker.driver_found.connect(self._on_driver_found)
        self._scan_worker.finished.connect(self._on_scan_finished)
        self._scan_worker.error.connect(self._on_scan_error)
        self._scan_worker.start()

    def _on_scan_progress(self, pct: int, msg: str):
        self._progress.setValue(pct)
        self._status_lbl.setText(msg)

    def _on_driver_found(self, driver: dict):
        self._all_drivers.append(driver)
        self._model.load_drivers(list(self._all_drivers))
        self._apply_filter()
        self._update_cards_from_all()

    def _on_scan_finished(self, drivers: list[dict]):
        self._all_drivers = drivers
        self._model.load_drivers(drivers)
        self._apply_filter()
        self._update_cards_from_all()
        self._progress.setVisible(False)
        self._scan_btn.setEnabled(True)
        self._update_all_btn.setEnabled(True)
        n = len(drivers)
        prob = sum(1 for d in drivers if d["status"] in (STATUS_ERROR, STATUS_MISSING, STATUS_OUTDATED))
        self._log(f"Scan complete: {n} devices found, {prob} problem(s) detected.", SUCCESS.name())
        self._status_lbl.setText(f"Scan complete — {n} devices, {prob} problems.")

    def _on_scan_error(self, msg: str):
        self._progress.setVisible(False)
        self._scan_btn.setEnabled(True)
        self._log(f"Scan error: {msg}", DANGER.name())
        QMessageBox.critical(self, "Scan Error",
                             f"Driver scan failed:\n\n{msg}\n\n"
                             "Ensure you are running on Windows with appropriate permissions.")

    # ---------------------------------------------------------------
    # Update Logic
    # ---------------------------------------------------------------

    def _update_all_problems(self):
        problems = [d for d in self._all_drivers
                    if d["status"] in (STATUS_ERROR, STATUS_MISSING, STATUS_OUTDATED)]
        if not problems:
            QMessageBox.information(self, "No Problems", "No problem drivers detected.")
            return
        self._run_update(problems)

    def _update_selected(self):
        idxs = self._table.selectionModel().selectedRows()
        if not idxs:
            self._log("No rows selected.", WARNING.name())
            return
        drivers = []
        for idx in idxs:
            src_idx = self._proxy.mapToSource(idx)
            drv = self._model.get_driver(src_idx.row())
            if drv:
                drivers.append(drv)
        if not drivers:
            return
        self._run_update(drivers)

    def _update_single(self, driver: dict):
        self._run_update([driver])

    def _run_update(self, drivers: list[dict]):
        if self._update_worker and self._update_worker.isRunning():
            self._log("Update already in progress.", WARNING.name())
            return
        names = "\n".join(f"  • {d['name']}" for d in drivers[:10])
        if len(drivers) > 10:
            names += f"\n  … and {len(drivers) - 10} more"
        resp = QMessageBox.question(
            self, "Confirm Update",
            f"Update {len(drivers)} driver(s)?\n\n{names}\n\n"
            "Windows Update will be used. A restart may be required.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if resp != QMessageBox.StandardButton.Yes:
            return

        self._progress.setValue(0)
        self._progress.setVisible(True)
        self._scan_btn.setEnabled(False)
        self._update_all_btn.setEnabled(False)
        self._log(f"Starting update of {len(drivers)} driver(s)...", ACCENT_LT.name())

        self._update_worker = UpdateWorker(drivers, self)
        self._update_worker.progress.connect(self._on_update_progress)
        self._update_worker.log.connect(self._log)
        self._update_worker.driver_updated.connect(self._on_driver_status_changed)
        self._update_worker.finished.connect(self._on_update_finished)
        self._update_worker.start()

    def _on_update_progress(self, pct: int, msg: str):
        self._progress.setValue(pct)
        self._status_lbl.setText(msg)

    def _on_driver_status_changed(self, instance_id: str, status: str):
        self._model.update_driver_status(instance_id, status)
        # Update the all-drivers list too
        for d in self._all_drivers:
            if d.get("instance_id") == instance_id:
                d["status"] = status
                break
        self._update_cards_from_all()

    def _on_update_finished(self, success: int, fail: int):
        self._progress.setVisible(False)
        self._scan_btn.setEnabled(True)
        self._update_all_btn.setEnabled(True)
        msg = f"Update complete: {success} succeeded, {fail} failed."
        self._log(msg, SUCCESS.name() if fail == 0 else WARNING.name())
        self._status_lbl.setText(msg)
        if success > 0:
            QMessageBox.information(self, "Update Complete",
                                    f"{msg}\n\nA system restart may be required for changes to take effect.")

    # ---------------------------------------------------------------
    # Filter & Selection
    # ---------------------------------------------------------------

    # Providers / name fragments considered virtual or 3rd-party
    _VIRTUAL_PROVIDERS = {
        "oracle corporation", "vmware", "virtualbox", "parallels",
        "qemu", "hyper-v", "xen", "citrix", "nuvoton", "realtek semiconductor"
    }
    _VIRTUAL_NAME_FRAGMENTS = [
        "virtualbox", "vmware", "virtual", "hyper-v", "qemu", "xen",
    ]

    def _is_virtual_or_3rdparty(self, d: dict) -> bool:
        provider = (d.get("provider") or "").lower()
        name     = (d.get("name") or "").lower()
        if any(v in provider for v in self._VIRTUAL_PROVIDERS):
            return True
        if any(f in name for f in self._VIRTUAL_NAME_FRAGMENTS):
            return True
        return False

    def _apply_filter(self):
        filter_idx = self._filter_combo.currentIndex()
        search     = self._search_box.text().strip().lower()

        visible = []
        for d in self._all_drivers:
            status = d.get("status", STATUS_UNKNOWN)
            name   = d.get("name", "").lower()

            if filter_idx == 1 and status not in (STATUS_ERROR, STATUS_MISSING, STATUS_OUTDATED):
                continue
            if filter_idx == 2 and status != STATUS_OK:
                continue
            if filter_idx == 3 and status != STATUS_UNKNOWN:
                continue
            if filter_idx == 4 and self._is_virtual_or_3rdparty(d):
                continue
            if search and search not in name:
                continue
            visible.append(d)

        self._model.load_drivers(visible)

    def _on_selection_changed(self):
        idxs = self._table.selectionModel().selectedRows()
        if len(idxs) == 1:
            src = self._proxy.mapToSource(idxs[0])
            drv = self._model.get_driver(src.row())
            if drv:
                self._detail_panel.load_driver(drv)
        else:
            self._detail_panel.clear()

    # ---------------------------------------------------------------
    # Cards
    # ---------------------------------------------------------------

    def _update_cards_from_all(self):
        ok      = [d for d in self._all_drivers if d["status"] == STATUS_OK]
        prob    = [d for d in self._all_drivers if d["status"] in (STATUS_ERROR, STATUS_MISSING, STATUS_OUTDATED)]
        unknown = [d for d in self._all_drivers if d["status"] == STATUS_UNKNOWN]
        self._update_cards(self._all_drivers, ok, prob, unknown)

    def _update_cards(self, total, ok, problems, unknown):
        self._card_total.set_value(str(len(total)))
        self._card_ok.set_value(str(len(ok)), SUCCESS)
        self._card_problems.set_value(str(len(problems)), DANGER if problems else SUCCESS)
        self._card_unknown.set_value(str(len(unknown)), TEXT_DIM)

    # ---------------------------------------------------------------
    # Export
    # ---------------------------------------------------------------

    def _export_report(self):
        if not self._all_drivers:
            QMessageBox.warning(self, "No Data", "Please run a scan first.")
            return

        path, _ = QFileDialog.getSaveFileName(
            self, "Export Driver Report", "dell_of_death_report.txt",
            "Text Files (*.txt);;CSV Files (*.csv);;All Files (*)"
        )
        if not path:
            return

        def _s(val, max_len=None) -> str:
            """Safely convert a driver field to string, handling None."""
            result = str(val) if val is not None else ""
            return result[:max_len] if max_len else result

        try:
            is_csv = path.lower().endswith(".csv")

            if is_csv:
                import csv
                with open(path, "w", newline="", encoding="utf-8") as f:
                    writer = csv.writer(f)
                    writer.writerow(["Device Name", "Class", "Status", "Version",
                                     "Provider", "Driver Date", "Instance ID"])
                    for d in self._all_drivers:
                        writer.writerow([
                            _s(d.get("name")),
                            _s(d.get("class")),
                            _s(d.get("status")),
                            _s(d.get("version")),
                            _s(d.get("provider")),
                            _s(d.get("date")),
                            _s(d.get("instance_id")),
                        ])
            else:
                ok_count   = sum(1 for d in self._all_drivers if d.get("status") == STATUS_OK)
                prob_count = sum(1 for d in self._all_drivers
                                 if d.get("status") in (STATUS_ERROR, STATUS_MISSING, STATUS_OUTDATED))
                lines = [
                    f"{APP_NAME} — Driver Report",
                    f"Generated : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    f"Software  : {ORG_NAME}",
                    "=" * 130,
                    f"Total Devices : {len(self._all_drivers)}   "
                    f"OK : {ok_count}   Problems : {prob_count}",
                    "=" * 130,
                    "",
                    f"{'Device Name':<50} {'Class':<16} {'Status':<10} {'Version':<22} {'Provider':<30} {'Driver Date'}",
                    "-" * 130,
                ]
                for d in self._all_drivers:
                    lines.append(
                        f"{_s(d.get('name'), 49):<50} "
                        f"{_s(d.get('class'), 15):<16} "
                        f"{_s(d.get('status'), 9):<10} "
                        f"{_s(d.get('version'), 21):<22} "
                        f"{_s(d.get('provider'), 29):<30} "
                        f"{_s(d.get('date'))}"
                    )
                lines += [
                    "",
                    "-" * 130,
                    "--- Problem Devices ---",
                    "",
                ]
                problems = [d for d in self._all_drivers
                            if d.get("status") in (STATUS_ERROR, STATUS_MISSING, STATUS_OUTDATED)]
                if problems:
                    for d in problems:
                        lines.append(f"  [{_s(d.get('status'))}]  {_s(d.get('name'))}  —  "
                                     f"Instance: {_s(d.get('instance_id'))}")
                else:
                    lines.append("  No problem devices detected.")

                Path(path).write_text("\n".join(lines), encoding="utf-8")

            self._log(f"Report exported to: {path}", SUCCESS.name())
        except Exception as e:
            QMessageBox.critical(self, "Export Failed", str(e))

    # ---------------------------------------------------------------
    # Helpers
    # ---------------------------------------------------------------

    def _log(self, msg: str, color: str = None):
        self._log_panel.append_log(msg, color)

    def _show_about(self):
        QMessageBox.about(
            self, f"About {APP_NAME}",
            f"<b style='font-family:Courier'>{APP_NAME}</b><br>"
            f"Version {APP_VERSION}<br><br>"
            f"<i>{ORG_NAME}</i><br><br>"
            "Windows driver scanning and management tool.<br>"
            "Uses PowerShell / PnP Device Manager to detect<br>"
            "and update missing or outdated drivers via Windows Update.<br><br>"
            "<b>Requirements:</b> Windows 10/11, Administrator privileges"
        )


# =============================================================================
# Entry Point
# =============================================================================

def main():
    _require_admin()   # Re-launch with UAC if not already admin
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)

    # Load icon — explicitly add all standard sizes so Windows picks the
    # right resolution for taskbar (32px), Alt+Tab (48px), title bar (16px), etc.
    icon_path = Path(__file__).parent / "icon.ico"
    app_icon = QIcon()
    if icon_path.exists():
        for size in (16, 24, 32, 48, 64, 128, 256):
            pix = QPixmap(str(icon_path))
            if not pix.isNull():
                app_icon.addPixmap(
                    pix.scaled(size, size,
                               Qt.AspectRatioMode.KeepAspectRatio,
                               Qt.TransformationMode.SmoothTransformation)
                )
    app.setWindowIcon(app_icon)

    # Splash
    splash = create_splash()
    if splash:
        splash.setWindowIcon(app_icon)
        splash.show()
        messages = [
            "Initializing...",
            "Loading driver database...",
            "Preparing interface...",
            "Almost ready...",
        ]
        for msg in messages:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255)
            )
            app.processEvents()
            time.sleep(0.45)

    # Main window
    window = DriversOfDeath()
    window.show()

    if splash:
        splash.finish(window)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
